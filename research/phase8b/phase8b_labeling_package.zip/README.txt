Phase 8B human-labelling package. Fill human_label (A-J) in both CSVs per phase8b_labeling_guide.md. Full texts: labeling_texts/<accession>.txt. Do not look up prices, returns or later filings.
